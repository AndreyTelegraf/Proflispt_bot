"""Publisher service for Work in Portugal Bot."""

import logging
from typing import Optional
from aiogram import Bot
from aiogram.types import Message

from config import Config
from models.job_posting import JobPosting
from services.formatting import format_job_posting
from database import db

logger = logging.getLogger(__name__)


class Publisher:
    """Service for publishing job postings to channel."""
    
    def __init__(self, bot: Bot):
        self.bot = bot
    
    async def publish_posting(self, posting: JobPosting, user_id: int) -> Optional[Message]:
        """Publish job posting to channel."""
        try:
            # Format posting text
            posting_text = format_job_posting(posting)
            
            # Determine topic ID based on mode
            topic_id = None
            if posting.mode == "seeking":
                topic_id = Config.JOB_SEEKING_TOPIC_ID
            elif posting.mode == "offering":
                topic_id = Config.JOB_OFFERING_TOPIC_ID
            
            # Publish to channel
            message = await self.bot.send_message(
                chat_id=Config.CHANNEL_ID,
                text=posting_text,
                message_thread_id=topic_id,
                disable_web_page_preview=True,
                parse_mode="Markdown"
            )
            
            logger.info(f"Published posting {posting.id} to channel")
            
            # Save posting to database with message info
            if posting.id:
                db.update_posting(
                    posting.id,
                    message_id=message.message_id,
                    chat_id=message.chat.id,
                    topic_id=topic_id
                )
            
            return message
            
        except Exception as e:
            logger.error(f"Failed to publish posting: {e}")
            return None
    
    async def delete_posting(self, posting: JobPosting) -> bool:
        """Delete posting from channel."""
        try:
            if posting.message_id and posting.chat_id:
                await self.bot.delete_message(
                    chat_id=posting.chat_id,
                    message_id=posting.message_id
                )
                
                logger.info(f"Deleted posting {posting.id} from channel")
                return True
            else:
                logger.warning(f"No message info for posting {posting.id}")
                return False
                
        except Exception as e:
            logger.error(f"Failed to delete posting: {e}")
            return False
    
    async def edit_posting(self, posting: JobPosting) -> bool:
        """Edit posting in channel."""
        try:
            if posting.message_id and posting.chat_id:
                # Format updated posting text
                posting_text = format_job_posting(posting)
                
                await self.bot.edit_message_text(
                    chat_id=posting.chat_id,
                    message_id=posting.message_id,
                    text=posting_text,
                    parse_mode="Markdown"
                )
                
                logger.info(f"Edited posting {posting.id} in channel")
                return True
            else:
                logger.warning(f"No message info for posting {posting.id}")
                return False
                
        except Exception as e:
            logger.error(f"Failed to edit posting: {e}")
            return False
