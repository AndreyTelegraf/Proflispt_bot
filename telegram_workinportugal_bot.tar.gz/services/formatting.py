"""Formatting service for Work in Portugal Bot."""

from typing import List
from models.job_posting import JobPosting
from services.validation import format_phone_number
from utils import format_social_media, get_social_media_name, clean_text, clean_user_input, clean_text_advanced, clean_user_input_advanced, get_link_type_and_name, remove_urls_from_text, format_link_as_markdown
from config import Config


def format_job_posting(posting: JobPosting) -> str:
    """Format job posting for publication."""
    lines = []
    
    # 1. Hashtags
    hashtags = []
    for city in posting.cities:
        if city == "online":
            hashtags.append("#online")
        else:
            hashtags.append(f"#{city}")
    
    lines.append(" ".join(hashtags))
    
    # 2. Description (cleaned with advanced cleaning for publication)
    cleaned_description = clean_text_advanced(posting.description)
    
    lines.append(cleaned_description)
    
    # 3. Links (websites, social media, portfolio, etc.)
    if posting.social_media and posting.social_media.lower() not in ['нет', 'no', 'none', '']:
        try:
            import json
            links = json.loads(posting.social_media) if posting.social_media.startswith('[') else [posting.social_media] if posting.social_media != 'нет' else []
            for link in links:
                formatted_link = format_link_as_markdown(link)
                lines.append(formatted_link)
        except (json.JSONDecodeError, AttributeError):
            # Fallback for old format
            formatted_link = format_link_as_markdown(posting.social_media)
            lines.append(formatted_link)
    
    # 4. Telegram username
    lines.append(posting.telegram_username)
    
    # 5. Phone numbers
    lines.append(format_phone_number(posting.phone_main))
    
    # 6. WhatsApp (only if different from main phone)
    if posting.phone_whatsapp and posting.phone_whatsapp != posting.phone_main:
        if posting.phone_whatsapp.lower() not in ['нет', 'no', 'none', '']:
            lines.append(format_phone_number(posting.phone_whatsapp))
    
    # 7. Name
    lines.append(f"- {posting.name}")
    
    return "\n".join(lines)


def format_preview(posting: JobPosting) -> str:
    """Format job posting preview."""
    mode_text = "Ищу работу" if posting.mode == "seeking" else "Предлагаю работу"
    cities_text = ", ".join([Config.CITIES.get(city, city) for city in posting.cities])
    
    # Clean description for preview
    cleaned_description = clean_user_input_advanced(posting.description)
    
    preview_description = cleaned_description[:100] + ('...' if len(cleaned_description) > 100 else '')
    
    preview = f"📋 **Предварительный просмотр**\n\n"
    preview += f"**Тип:** {mode_text}\n"
    preview += f"**Города:** {cities_text}\n"
    preview += f"**Описание:** {preview_description}\n"
    
    if posting.social_media and posting.social_media.lower() not in ['нет', 'no', 'none', '']:
        try:
            import json
            links = json.loads(posting.social_media) if posting.social_media.startswith('[') else [posting.social_media] if posting.social_media != 'нет' else []
            for link in links:
                formatted_link = format_link_as_markdown(link)
                preview += f"{formatted_link}\n"
        except (json.JSONDecodeError, AttributeError):
            # Fallback for old format
            formatted_link = format_link_as_markdown(posting.social_media)
            preview += f"{formatted_link}\n"
    
    preview += f"**Telegram:** {posting.telegram_username}\n"
    preview += f"**Телефон:** {format_phone_number(posting.phone_main)}\n"
    
    if posting.phone_whatsapp and posting.phone_whatsapp != posting.phone_main:
        if posting.phone_whatsapp.lower() not in ['нет', 'no', 'none', '']:
            preview += f"**WhatsApp:** {format_phone_number(posting.phone_whatsapp)}\n"
    
    preview += f"**Имя:** {posting.name}\n\n"
    preview += "Проверьте информацию выше. Все верно?"
    
    return preview


def format_user_postings_list(postings: List[JobPosting]) -> str:
    """Format list of user's postings."""
    if not postings:
        return "У вас пока нет опубликованных объявлений."
    
    result = "📋 **Ваши объявления:**\n\n"
    
    for i, posting in enumerate(postings, 1):
        mode_emoji = "🔍" if posting.mode == "seeking" else "💼"
        mode_text = "Ищу работу" if posting.mode == "seeking" else "Предлагаю работу"
        cities_text = ", ".join([Config.CITIES.get(city, city) for city in posting.cities])
        
        # Clean description for list view
        cleaned_description = clean_user_input_advanced(posting.description)
        
        list_description = cleaned_description[:50] + ('...' if len(cleaned_description) > 50 else '')
        
        result += f"{i}. {mode_emoji} **{mode_text}**\n"
        result += f"   📍 {cities_text}\n"
        result += f"   📝 {list_description}\n"
        result += f"   📅 {posting.created_at.strftime('%d.%m.%Y') if posting.created_at else 'N/A'}\n"
        result += f"   🆔 ID: {posting.id}\n\n"
    
    return result
