#!/usr/bin/env python3
"""Script to reset webhook for Telegram bot."""

import requests
import json
from config import Config

def reset_webhook():
    """Reset webhook for the bot."""
    bot_token = Config.BOT_TOKEN
    url = f"https://api.telegram.org/bot{bot_token}/deleteWebhook"
    
    print(f"Resetting webhook for bot...")
    
    try:
        response = requests.get(url)
        result = response.json()
        
        if result.get('ok'):
            print("✅ Webhook successfully reset!")
            print(f"Result: {result}")
        else:
            print("❌ Failed to reset webhook")
            print(f"Error: {result}")
            
    except Exception as e:
        print(f"❌ Error resetting webhook: {e}")

def get_webhook_info():
    """Get current webhook info."""
    bot_token = Config.BOT_TOKEN
    url = f"https://api.telegram.org/bot{bot_token}/getWebhookInfo"
    
    print(f"Getting webhook info...")
    
    try:
        response = requests.get(url)
        result = response.json()
        
        if result.get('ok'):
            webhook_info = result.get('result', {})
            print("📋 Current webhook info:")
            print(json.dumps(webhook_info, indent=2))
        else:
            print("❌ Failed to get webhook info")
            print(f"Error: {result}")
            
    except Exception as e:
        print(f"❌ Error getting webhook info: {e}")

if __name__ == "__main__":
    print("🔄 Telegram Bot Webhook Reset Tool")
    print("=" * 40)
    
    # Get current webhook info
    get_webhook_info()
    print()
    
    # Reset webhook
    reset_webhook()
    print()
    
    # Get webhook info again
    get_webhook_info()
