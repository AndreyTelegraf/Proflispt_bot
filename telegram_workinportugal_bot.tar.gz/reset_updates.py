#!/usr/bin/env python3
"""Script to reset all updates for Telegram bot."""

import requests
import json
from config import Config

def reset_updates():
    """Reset all updates for the bot."""
    bot_token = Config.BOT_TOKEN
    
    # Method 1: Delete webhook
    delete_webhook_url = f"https://api.telegram.org/bot{bot_token}/deleteWebhook"
    
    print("🔄 Resetting bot state...")
    
    try:
        # Delete webhook
        response = requests.get(delete_webhook_url)
        result = response.json()
        print(f"Delete webhook result: {result}")
        
        # Method 2: Get updates with offset to clear queue
        get_updates_url = f"https://api.telegram.org/bot{bot_token}/getUpdates"
        params = {"offset": -1, "limit": 1}
        
        response = requests.get(get_updates_url, params=params)
        result = response.json()
        print(f"Get updates result: {result}")
        
        if result.get('ok') and result.get('result'):
            # Get the last update_id and set offset to clear all updates
            last_update = result['result'][-1]
            last_update_id = last_update['update_id']
            
            # Set offset to clear all updates
            clear_params = {"offset": last_update_id + 1}
            response = requests.get(get_updates_url, params=clear_params)
            clear_result = response.json()
            print(f"Clear updates result: {clear_result}")
            
        print("✅ Bot state reset completed!")
        
    except Exception as e:
        print(f"❌ Error resetting bot state: {e}")

def test_bot_connection():
    """Test if bot can connect to Telegram API."""
    bot_token = Config.BOT_TOKEN
    url = f"https://api.telegram.org/bot{bot_token}/getMe"
    
    print("🔍 Testing bot connection...")
    
    try:
        response = requests.get(url)
        result = response.json()
        
        if result.get('ok'):
            bot_info = result.get('result', {})
            print("✅ Bot connection successful!")
            print(f"Bot info: {json.dumps(bot_info, indent=2)}")
            return True
        else:
            print("❌ Bot connection failed")
            print(f"Error: {result}")
            return False
            
    except Exception as e:
        print(f"❌ Error testing bot connection: {e}")
        return False

if __name__ == "__main__":
    print("🔄 Telegram Bot Reset Tool")
    print("=" * 40)
    
    # Test connection first
    if test_bot_connection():
        print()
        # Reset updates
        reset_updates()
    else:
        print("❌ Cannot proceed - bot connection failed")
