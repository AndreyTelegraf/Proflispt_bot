#!/usr/bin/env python3
"""Force restart script with conflict resolution."""

import subprocess
import time
import logging
import requests
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BOT_TOKEN = "8405113240:AAEksoQZrlJIyj-0vWYnShP3GcgcWyVQX48"

def check_telegram_status():
    """Check if Telegram API is available without conflicts."""
    try:
        response = requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates", timeout=5)
        data = response.json()
        
        if data.get("ok") and not data.get("result"):
            return True
        elif "Conflict" in str(data):
            return False
        else:
            return True
    except Exception as e:
        logger.warning(f"Ошибка проверки статуса: {e}")
        return False

def force_restart():
    """Force restart with conflict resolution."""
    
    logger.info("🔥 Принудительный перезапуск бота...")
    
    # 1. Остановить все процессы
    logger.info("1️⃣ Останавливаем все процессы...")
    subprocess.run(["pkill", "-f", "python3 main.py"], check=False)
    subprocess.run(["pkill", "-9", "-f", "python3 main.py"], check=False)
    time.sleep(5)
    
    # 2. Удалить webhook
    logger.info("2️⃣ Удаляем webhook...")
    subprocess.run([
        "curl", "-s", 
        f"https://api.telegram.org/bot{BOT_TOKEN}/deleteWebhook"
    ], check=False)
    time.sleep(2)
    
    # 3. Очистить обновления
    logger.info("3️⃣ Очищаем обновления...")
    subprocess.run([
        "curl", "-s", 
        f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates?offset=999999999"
    ], check=False)
    time.sleep(2)
    
    # 4. Ждать разрешения конфликта
    logger.info("4️⃣ Ждем разрешения конфликта...")
    max_attempts = 10
    for attempt in range(max_attempts):
        if check_telegram_status():
            logger.info(f"✅ Конфликт разрешен на попытке {attempt + 1}")
            break
        else:
            logger.info(f"⏳ Попытка {attempt + 1}/{max_attempts} - конфликт еще есть")
            time.sleep(3)
    else:
        logger.warning("⚠️ Не удалось полностью разрешить конфликт, продолжаем...")
    
    # 5. Запустить бота
    logger.info("5️⃣ Запускаем бота...")
    try:
        process = subprocess.Popen(
            ["python3", "main.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        logger.info(f"✅ Бот запущен (PID: {process.pid})")
    except Exception as e:
        logger.error(f"❌ Ошибка запуска: {e}")
        return False
    
    # 6. Проверить статус
    time.sleep(5)
    logger.info("6️⃣ Проверяем статус...")
    try:
        result = subprocess.run(["tail", "-5", "bot.log"], 
                              capture_output=True, text=True, timeout=10)
        if result.stdout:
            logger.info("📋 Последние логи:")
            for line in result.stdout.strip().split('\n'):
                logger.info(f"   {line}")
    except Exception as e:
        logger.warning(f"⚠️ Не удалось прочитать логи: {e}")
    
    logger.info("🎉 Принудительный перезапуск завершен!")
    return True

if __name__ == "__main__":
    force_restart()
