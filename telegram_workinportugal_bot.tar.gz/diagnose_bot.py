#!/usr/bin/env python3
"""Complete bot diagnosis script."""

import requests
import json
import subprocess
import os
from config import Config

def check_bot_info():
    """Check bot information."""
    bot_token = Config.BOT_TOKEN
    url = f"https://api.telegram.org/bot{bot_token}/getMe"
    
    print("🔍 Checking bot information...")
    
    try:
        response = requests.get(url)
        result = response.json()
        
        if result.get('ok'):
            bot_info = result.get('result', {})
            print("✅ Bot info retrieved successfully:")
            print(f"   ID: {bot_info.get('id')}")
            print(f"   Name: {bot_info.get('first_name')}")
            print(f"   Username: @{bot_info.get('username')}")
            return True
        else:
            print("❌ Failed to get bot info")
            print(f"   Error: {result}")
            return False
            
    except Exception as e:
        print(f"❌ Error getting bot info: {e}")
        return False

def check_webhook_status():
    """Check webhook status."""
    bot_token = Config.BOT_TOKEN
    url = f"https://api.telegram.org/bot{bot_token}/getWebhookInfo"
    
    print("\n🔍 Checking webhook status...")
    
    try:
        response = requests.get(url)
        result = response.json()
        
        if result.get('ok'):
            webhook_info = result.get('result', {})
            print("✅ Webhook info retrieved:")
            print(f"   URL: {webhook_info.get('url', 'Not set')}")
            print(f"   Has custom certificate: {webhook_info.get('has_custom_certificate', False)}")
            print(f"   Pending updates: {webhook_info.get('pending_update_count', 0)}")
            print(f"   Allowed updates: {webhook_info.get('allowed_updates', [])}")
            return webhook_info
        else:
            print("❌ Failed to get webhook info")
            print(f"   Error: {result}")
            return None
            
    except Exception as e:
        print(f"❌ Error getting webhook info: {e}")
        return None

def check_updates():
    """Check for pending updates."""
    bot_token = Config.BOT_TOKEN
    url = f"https://api.telegram.org/bot{bot_token}/getUpdates"
    
    print("\n🔍 Checking for pending updates...")
    
    try:
        response = requests.get(url)
        result = response.json()
        
        if result.get('ok'):
            updates = result.get('result', [])
            print(f"✅ Found {len(updates)} pending updates")
            
            if updates:
                print("   Recent updates:")
                for i, update in enumerate(updates[-3:]):  # Show last 3
                    update_id = update.get('update_id')
                    print(f"     Update {i+1}: ID={update_id}")
            return updates
        else:
            print("❌ Failed to get updates")
            print(f"   Error: {result}")
            return None
            
    except Exception as e:
        print(f"❌ Error getting updates: {e}")
        return None

def clear_all_updates():
    """Clear all pending updates."""
    bot_token = Config.BOT_TOKEN
    url = f"https://api.telegram.org/bot{bot_token}/getUpdates"
    
    print("\n🧹 Clearing all pending updates...")
    
    try:
        # First get updates to find the last update_id
        response = requests.get(url)
        result = response.json()
        
        if result.get('ok'):
            updates = result.get('result', [])
            if updates:
                # Get the last update_id and set offset to clear all
                last_update_id = updates[-1]['update_id']
                clear_params = {"offset": last_update_id + 1}
                
                response = requests.get(url, params=clear_params)
                clear_result = response.json()
                
                if clear_result.get('ok'):
                    print("✅ All updates cleared successfully")
                    return True
                else:
                    print("❌ Failed to clear updates")
                    print(f"   Error: {clear_result}")
                    return False
            else:
                print("✅ No updates to clear")
                return True
        else:
            print("❌ Failed to get updates for clearing")
            print(f"   Error: {result}")
            return False
            
    except Exception as e:
        print(f"❌ Error clearing updates: {e}")
        return False

def check_local_processes():
    """Check for local bot processes."""
    print("\n🔍 Checking for local bot processes...")
    
    try:
        # Check for Python processes running bot files
        result = subprocess.run(['ps', 'aux'], capture_output=True, text=True)
        
        if result.returncode == 0:
            lines = result.stdout.split('\n')
            bot_processes = []
            
            for line in lines:
                if 'python' in line and ('main.py' in line or 'bot' in line):
                    bot_processes.append(line.strip())
            
            if bot_processes:
                print("⚠️  Found potential bot processes:")
                for process in bot_processes:
                    print(f"   {process}")
            else:
                print("✅ No local bot processes found")
            
            return bot_processes
        else:
            print("❌ Failed to check processes")
            return []
            
    except Exception as e:
        print(f"❌ Error checking processes: {e}")
        return []

def check_lock_files():
    """Check for lock files."""
    print("\n🔍 Checking for lock files...")
    
    lock_files = ['bot.lock', 'bot.pid', 'bot_alt.lock']
    found_files = []
    
    for lock_file in lock_files:
        if os.path.exists(lock_file):
            found_files.append(lock_file)
            print(f"⚠️  Found lock file: {lock_file}")
    
    if not found_files:
        print("✅ No lock files found")
    
    return found_files

def main():
    """Main diagnosis function."""
    print("🔬 Telegram Bot Diagnosis Tool")
    print("=" * 50)
    
    # Check bot info
    if not check_bot_info():
        print("❌ Cannot proceed - bot info check failed")
        return
    
    # Check webhook status
    webhook_info = check_webhook_status()
    
    # Check updates
    updates = check_updates()
    
    # Check local processes
    processes = check_local_processes()
    
    # Check lock files
    lock_files = check_lock_files()
    
    print("\n📊 Diagnosis Summary:")
    print("=" * 50)
    
    if webhook_info and webhook_info.get('url'):
        print("⚠️  Webhook is set - this may cause conflicts")
    else:
        print("✅ No webhook set")
    
    if updates:
        print(f"⚠️  {len(updates)} pending updates found")
    else:
        print("✅ No pending updates")
    
    if processes:
        print(f"⚠️  {len(processes)} potential bot processes found")
    else:
        print("✅ No local bot processes")
    
    if lock_files:
        print(f"⚠️  {len(lock_files)} lock files found")
    else:
        print("✅ No lock files")
    
    print("\n💡 Recommendations:")
    print("=" * 50)
    
    if webhook_info and webhook_info.get('url'):
        print("1. Delete webhook if not needed")
    
    if updates:
        print("2. Clear pending updates")
    
    if processes:
        print("3. Stop local bot processes")
    
    if lock_files:
        print("4. Remove lock files")
    
    print("5. Wait 1-2 minutes before restarting bot")
    print("6. Check if bot is running on another device/server")

if __name__ == "__main__":
    main()
