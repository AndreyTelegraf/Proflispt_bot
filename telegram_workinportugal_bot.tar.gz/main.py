"""Main entry point for Work in Portugal Bot."""

import asyncio
import logging
import sys
import os
import signal
import atexit
import fcntl
import subprocess
from datetime import datetime

from aiogram import Bot, Dispatcher, Router, F
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import Config
from handlers.posting import router as posting_router
from handlers.my_postings import router as my_postings_router
from services.scheduler import start_scheduler, stop_scheduler

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("bot.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Lock file for preventing multiple instances
LOCK_FILE = "bot.lock"

def cleanup_stale_processes():
    """Clean up stale processes and lock files."""
    logger.info("Cleaning up stale processes...")
    
    try:
        # Kill any existing python processes running main.py
        result = subprocess.run(['pkill', '-f', 'python3 main.py'], 
                              capture_output=True, timeout=5)
        if result.returncode == 0:
            logger.info("Killed existing bot processes")
        else:
            logger.info("No existing bot processes found")
    except Exception as e:
        logger.warning(f"Error killing processes: {e}")
    
    # Remove stale lock file
    if os.path.exists(LOCK_FILE):
        try:
            os.remove(LOCK_FILE)
            logger.info("Removed stale lock file")
        except Exception as e:
            logger.warning(f"Error removing lock file: {e}")

class SingleInstance:
    """Ensure only one instance of the bot is running."""
    
    def __init__(self, lockfile):
        self.lockfile = lockfile
        self.fd = None
        
    def __enter__(self):
        """Acquire lock."""
        try:
            self.fd = open(self.lockfile, 'w')
            fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            logger.info(f"Lock acquired: {self.lockfile}")
            return self
        except IOError:
            logger.error(f"Another bot instance is already running")
            if self.fd:
                self.fd.close()
            sys.exit(1)
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Release lock."""
        if self.fd:
            try:
                fcntl.flock(self.fd, fcntl.LOCK_UN)
                self.fd.close()
                os.remove(self.lockfile)
                logger.info("Lock released")
            except Exception as e:
                logger.warning(f"Error releasing lock: {e}")

def signal_handler(signum, frame):
    """Handle termination signals."""
    logger.info(f"Received signal {signum}, shutting down...")
    sys.exit(0)

# Register signal handlers
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

# Create router
router = Router()


def get_main_menu() -> InlineKeyboardMarkup:
    """Get main menu keyboard."""
    builder = InlineKeyboardBuilder()
    
    builder.add(InlineKeyboardButton(
        text="🔍 Ищу работу",
        callback_data="mode:seeking"
    ))
    
    builder.add(InlineKeyboardButton(
        text="💼 Предлагаю работу",
        callback_data="mode:offering"
    ))
    
    builder.add(InlineKeyboardButton(
        text="📋 Мои объявления",
        callback_data="my_postings"
    ))
    
    builder.add(InlineKeyboardButton(
        text="❓ Помощь",
        callback_data="help"
    ))
    
    builder.adjust(2)  # 2 buttons per row
    return builder.as_markup()


def get_back_button(back_to: str = "go:main") -> InlineKeyboardMarkup:
    """Get back button keyboard."""
    builder = InlineKeyboardBuilder()
    
    builder.add(InlineKeyboardButton(
        text="← Назад",
        callback_data=back_to
    ))
    
    return builder.as_markup()


@router.message(Command("start"))
async def cmd_start(message: Message, state: FSMContext):
    """Handle /start command."""
    await state.clear()
    
    logger.info(f"User {message.from_user.id} started bot")
    
    welcome_text = "🤖 Work in Portugal Bot\n\nДобро пожаловать! Этот бот поможет вам опубликовать объявления о поиске или предложении работы в разделы Справочника.\n\nВыберите действие:"
    
    await message.answer(welcome_text, reply_markup=get_main_menu())


@router.callback_query(F.data == "go:main")
async def show_main_menu(callback: CallbackQuery, state: FSMContext):
    """Show main menu."""
    await state.clear()
    
    welcome_text = "🤖 Work in Portugal Bot\n\nДобро пожаловать! Этот бот поможет вам опубликовать объявления о поиске или предложении работы в разделы Справочника.\n\nВыберите действие:"
    
    await callback.message.edit_text(welcome_text, reply_markup=get_main_menu())
    await callback.answer()


@router.callback_query(F.data == "help")
async def show_help(callback: CallbackQuery):
    """Show help menu."""
    help_text = "❓ Помощь\n\nОбщие правила:\n• Одно объявление не чаще раза в месяц\n• Максимум 3 активных объявления на пользователя\n• Объявления автоматически удаляются через 30 дней\n\nФормат объявления:\n• Хештеги городов (#lisboa, #porto, #online)\n• Описание работы (минимум 10 символов)\n• Социальные сети (или \"нет\")\n• Telegram @username\n• Телефон (+351xxxxxxxxx)\n• WhatsApp (если отличается)\n• Имя/название компании"
    
    # Create help keyboard with "Позвать человека" button
    builder = InlineKeyboardBuilder()
    builder.add(InlineKeyboardButton(
        text="👤 Позвать человека",
        url="https://t.me/andreytelegraf"
    ))
    builder.add(InlineKeyboardButton(
        text="← Назад",
        callback_data="go:main"
    ))
    builder.adjust(1)  # One button per row
    
    await callback.message.edit_text(help_text, reply_markup=builder.as_markup())
    await callback.answer()


@router.callback_query(F.data.startswith("mode:"))
async def handle_mode_selection(callback: CallbackQuery, state: FSMContext):
    """Handle job posting mode selection."""
    mode = callback.data.split(":")[1]
    
    if mode == "seeking":
        mode_text = "Ищу работу"
        warning_text = ""
    elif mode == "offering":
        mode_text = "Предлагаю работу"
        warning_text = "\n⚠️ Внимание: Публикация одной и той же вакансии допускается не чаще раза в месяц. При наличии нескольких вакансий рекомендуется объединить их в одно объявление."
    else:
        await callback.answer("Неизвестный режим")
        return
    
    await state.update_data(mode=mode)
    
    # Check user posting limit
    from database import db
    user_id = callback.from_user.id
    
    # Get or create user
    user = db.get_user(user_id)
    if not user:
        user_id_db = db.create_user(
            telegram_id=user_id,
            username=callback.from_user.username,
            first_name=callback.from_user.first_name,
            last_name=callback.from_user.last_name
        )
    else:
        user_id_db = user['id']
    
    # Check posting limit
    can_post, earliest_next_post_date = db.check_user_posting_limit(user_id_db)
    
    if not can_post:
        # Format the date for display
        date_str = earliest_next_post_date.strftime("%d.%m.%Y")
        
        limit_message = (
            f"⚠️ Лимит публикаций превышен\n\n"
            f"У вас уже есть 3 активных объявления за последние 30 дней.\n\n"
            f"Чтобы опубликовать ещё одно объявление, удалите минимум одно старое или подождите до {date_str}\n\n"
            f"Управляйте своими объявлениями в разделе 'Мои объявления'."
        )
        
        # Create keyboard with back button and my postings button
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📋 Мои объявления", callback_data="my_postings")],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="go:main")]
        ])
        
        await callback.message.edit_text(limit_message, reply_markup=keyboard)
        await callback.answer()
        return
    
    # User can post - continue with city selection
    response_text = f"Вы выбрали: {mode_text}{warning_text}\n\nНачнем создание объявления. Сначала выберите город или города:"
    
    # Create cities keyboard
    builder = InlineKeyboardBuilder()
    
    cities = [
        ("Lisboa", "city:lisboa"),
        ("Porto", "city:porto"),
        ("Algarve", "city:algarve"),
        ("Coimbra", "city:coimbra"),
        ("Braga", "city:braga"),
        ("Faro", "city:faro"),
        ("Sintra", "city:sintra"),
        ("Cascais", "city:cascais"),
        ("Leiria", "city:leiria"),
        ("Madeira", "city:madeira"),
        ("Онлайн", "city:online"),
        ("Другой город", "city:custom")
    ]
    
    for text, callback_data in cities:
        builder.add(InlineKeyboardButton(text=text, callback_data=callback_data))
    
    builder.add(InlineKeyboardButton(text="← Назад", callback_data="back_to_mode"))
    builder.adjust(3)  # 3 buttons per row
    
    await callback.message.edit_text(response_text, reply_markup=builder.as_markup())
    await callback.answer()


@router.callback_query(F.data == "back_to_mode")
async def back_to_mode_selection(callback: CallbackQuery, state: FSMContext):
    """Go back to mode selection."""
    # Clear cities from state
    await state.update_data(cities=None)
    
    # Show mode selection
    response_text = "Выберите тип объявления:"
    
    builder = InlineKeyboardBuilder()
    builder.add(InlineKeyboardButton(
        text="🔍 Ищу работу",
        callback_data="mode:seeking"
    ))
    builder.add(InlineKeyboardButton(
        text="💰 Предлагаю работу",
        callback_data="mode:offering"
    ))
    builder.add(InlineKeyboardButton(
        text="← Назад",
        callback_data="go:main"
    ))
    builder.adjust(2, 1)  # 2 buttons in first row, 1 in second
    
    await callback.message.edit_text(response_text, reply_markup=builder.as_markup())
    await callback.answer()


@router.callback_query(F.data.startswith("city:"))
async def handle_city_selection(callback: CallbackQuery, state: FSMContext):
    """Handle city selection."""
    city_key = callback.data.split(":")[1]
    
    # Get current mode from state
    state_data = await state.get_data()
    mode = state_data.get('mode', 'seeking')
    
    if city_key == "custom":
        await callback.message.edit_text(
            "Введите название города или городов (можно несколько через запят):",
            reply_markup=get_back_button("back_to_mode")
        )
        await state.set_state("waiting_for_custom_city")
    else:
        # Get city name from config
        city_name = Config.CITIES.get(city_key, city_key)
        
        # Save selected city
        await state.update_data(cities=[city_key])
        
        # Prepare description text based on mode
        if mode == "seeking":
            description_text = (
                f"Город: {city_name}\n\n"
                "Отправьте описание работы, которую вы ищите, например:\n"
                "• 'Ищу работу водителем с личным авто'\n"
                "• 'Ищу вакансию в разработке python'\n"
                "• 'Ищу подработку в сфере услуг'\n"
                "• 'Ищу парт-тайм официантом'\n"
                "• 'Ищу работу на стройке'\n"
                "Плюс ваше резюме или описание опыта и навыков.\n"
                "КОНТАКТЫ ПОКА НЕ НУЖНО"
            )
        else:  # offering
            description_text = (
                f"Город: {city_name}\n\n"
                "Отправьте описание вашей вакансии.\n"
                "Если вакансий несколько, сформируйте описание так, чтобы это было понятно.\n"
                "Начните с ключевых слов, например:\n"
                "• 'Предлагаю работу водителю с личным авто'\n"
                "• 'Требуется официант в кафе-ресторан'\n"
                "• 'Ищу кто сможет починить жалюзи'\n"
                "• 'Нужны разнорабочие на стройку'\n"
                "• 'Ищем уборщицу на парт-тайм'\n"
                "КОНТАКТЫ ПОКА НЕ НУЖНО"
            )
        
        # Ask for description
        await callback.message.edit_text(
            description_text,
            reply_markup=get_back_button("back_to_mode")
        )
        await state.set_state("waiting_for_description")
    
    await callback.answer()


# Text input handlers are now in handlers/posting.py





@router.message(Command("cleanup"))
async def cmd_cleanup(message: Message):
    """Handle /cleanup command (admin only)."""
    # Check if user is admin (you can customize this check)
    admin_ids = [336224597]  # Add admin Telegram IDs here
    
    if message.from_user.id not in admin_ids:
        await message.answer("❌ У вас нет прав для выполнения этой команды.")
        return
    
    await message.answer("🧹 Запуск очистки старых объявлений...")
    
    try:
        from services.scheduler import run_cleanup_now
        await run_cleanup_now(message.bot)
        await message.answer("✅ Очистка завершена!")
    except Exception as e:
        logger.error(f"Error during manual cleanup: {e}")
        await message.answer(f"❌ Ошибка при очистке: {e}")


async def main():
    """Main function."""
    try:
        # Clean up any stale processes first
        cleanup_stale_processes()
        
        # Check if another instance is already running
        with SingleInstance(LOCK_FILE):
            # Validate configuration
            Config.validate()
            logger.info("Configuration validated successfully")

            # Initialize bot and dispatcher
            bot = Bot(token=Config.BOT_TOKEN)
            dp = Dispatcher(storage=MemoryStorage())

            # Register routers
            dp.include_router(router)
            dp.include_router(posting_router)
            dp.include_router(my_postings_router)

            logger.info("Work in Portugal Bot started successfully")

            # Start cleanup scheduler
            await start_scheduler(bot)
            logger.info("Cleanup scheduler started")

            # Start the dispatcher
            await dp.start_polling(bot, skip_updates=True)
            
            # Wait for termination signal
            try:
                await asyncio.Event().wait()  # ждет, пока ты не убьёшь процесс
            except (KeyboardInterrupt, SystemExit):
                logger.info("Выключение...")
            finally:
                await stop_scheduler()
                await dp.stop_polling()
                await bot.session.close()

    except ValueError as e:
        logger.error(f"Configuration error: {e}")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        sys.exit(1)
    finally:
        logger.info("Bot stopped")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)
