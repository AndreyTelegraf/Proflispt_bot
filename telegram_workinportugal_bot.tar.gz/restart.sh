#!/bin/bash

echo "🚀 Перезапуск бота..."
python3 force_restart.py

echo ""
echo "✅ Готово! Бот перезапущен."
echo "📋 Для проверки логов: tail -f bot.log"
