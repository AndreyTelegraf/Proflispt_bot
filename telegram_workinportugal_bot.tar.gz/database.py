"""Database module for Work in Portugal Bot."""

import sqlite3
import json
import logging
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from contextlib import contextmanager
from config import Config

logger = logging.getLogger(__name__)


class Database:
    """Database manager for the bot."""

    def __init__(self, db_path: str = "bot_database.db"):
        self.db_path = db_path
        self.init_database()

    @contextmanager
    def get_connection(self):
        """Get database connection with context manager."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()

    def init_database(self):
        """Initialize database tables."""
        with self.get_connection() as conn:
            cursor = conn.cursor()

            # Users table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    telegram_id INTEGER UNIQUE NOT NULL,
                    username TEXT,
                    first_name TEXT,
                    last_name TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Job postings table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS job_postings (
                    id INTEGER PRIMARY KEY,
                    user_id INTEGER NOT NULL,
                    mode TEXT NOT NULL,
                    cities TEXT NOT NULL,
                    description TEXT NOT NULL,
                    social_media TEXT,
                    telegram_username TEXT NOT NULL,
                    phone_main TEXT NOT NULL,
                    phone_whatsapp TEXT,
                    name TEXT NOT NULL,
                    message_id INTEGER,
                    chat_id INTEGER,
                    topic_id INTEGER,
                    status TEXT DEFAULT 'active',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (id)
                )
            """)

            # Drafts table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS drafts (
                    id INTEGER PRIMARY KEY,
                    user_id INTEGER NOT NULL,
                    mode TEXT,
                    cities TEXT,
                    description TEXT,
                    social_media TEXT,
                    telegram_username TEXT,
                    phone_main TEXT,
                    phone_whatsapp TEXT,
                    name TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (id)
                )
            """)

            conn.commit()
            logger.info("Database initialized successfully")

    def create_user(self, telegram_id: int, username: Optional[str] = None, 
                   first_name: Optional[str] = None, last_name: Optional[str] = None) -> int:
        """Create or update user."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT OR REPLACE INTO users (telegram_id, username, first_name, last_name, updated_at)
                VALUES (?, ?, ?, ?, ?)
            """, (telegram_id, username, first_name, last_name, datetime.now()))
            
            conn.commit()
            
            # Get user ID
            cursor.execute("SELECT id FROM users WHERE telegram_id = ?", (telegram_id,))
            result = cursor.fetchone()
            return result['id'] if result else None

    def get_user(self, telegram_id: int) -> Optional[Dict[str, Any]]:
        """Get user by telegram ID."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE telegram_id = ?", (telegram_id,))
            result = cursor.fetchone()
            return dict(result) if result else None

    def create_job_posting(self, user_id: int, mode: str, cities: List[str], 
                          description: str, social_media: Optional[str], 
                          telegram_username: str, phone_main: str, 
                          phone_whatsapp: Optional[str], name: str) -> int:
        """Create job posting with links (websites, social media, portfolio, etc.)."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO job_postings 
                (user_id, mode, cities, description, social_media, telegram_username, 
                 phone_main, phone_whatsapp, name, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                user_id, mode, json.dumps(cities), description, social_media,
                telegram_username, phone_main, phone_whatsapp, name,
                datetime.now(), datetime.now()
            ))
            
            conn.commit()
            return cursor.lastrowid

    def get_user_postings(self, user_id: int) -> List[Dict[str, Any]]:
        """Get all postings for user."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM job_postings 
                WHERE user_id = ? AND status = 'active'
                ORDER BY created_at DESC
            """, (user_id,))
            
            results = cursor.fetchall()
            return [dict(row) for row in results]

    def get_posting_by_id(self, posting_id: int) -> Optional[Dict[str, Any]]:
        """Get posting by ID."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM job_postings WHERE id = ?", (posting_id,))
            result = cursor.fetchone()
            return dict(result) if result else None

    def update_posting(self, posting_id: int, **kwargs) -> bool:
        """Update posting."""
        if not kwargs:
            return False
            
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Build update query
            set_clause = ", ".join([f"{k} = ?" for k in kwargs.keys()])
            set_clause += ", updated_at = ?"
            
            values = list(kwargs.values()) + [datetime.now()]
            
            cursor.execute(f"UPDATE job_postings SET {set_clause} WHERE id = ?", 
                         values + [posting_id])
            
            conn.commit()
            return cursor.rowcount > 0

    def delete_posting(self, posting_id: int) -> bool:
        """Delete posting (soft delete)."""
        return self.update_posting(posting_id, status='deleted')

    def get_user_active_postings(self, user_id: int) -> list[dict]:
        """Get all active postings for user."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, mode, cities, description, name, created_at, message_id, chat_id, topic_id
                FROM job_postings 
                WHERE user_id = ? AND status = 'active'
                ORDER BY created_at DESC
            """, (user_id,))
            
            results = cursor.fetchall()
            return [dict(row) for row in results]

    def get_posting_statistics(self, user_id: int) -> dict:
        """
        Получает статистику публикаций пользователя.
        
        Returns:
            dict: статистика с информацией о лимитах и датах публикаций
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Получаем все активные объявления за последние 30 дней
            thirty_days_ago = datetime.now() - timedelta(days=30)
            
            cursor.execute("""
                SELECT id, mode, cities, name, created_at
                FROM job_postings 
                WHERE user_id = ? AND status = 'active' 
                AND created_at > ?
                ORDER BY created_at ASC
            """, (user_id, thirty_days_ago))
            
            recent_postings = cursor.fetchall()
            
            # Получаем все активные объявления (для отображения)
            cursor.execute("""
                SELECT id, mode, cities, name, created_at
                FROM job_postings 
                WHERE user_id = ? AND status = 'active'
                ORDER BY created_at DESC
            """, (user_id,))
            
            all_active_postings = cursor.fetchall()
            
            # Вычисляем статистику
            current_count = len(recent_postings)
            can_post = current_count < 3
            
            earliest_next_post_date = None
            if current_count == 3:
                oldest_posting_date_str = recent_postings[0]['created_at']
                if isinstance(oldest_posting_date_str, str):
                    oldest_posting_date = datetime.fromisoformat(oldest_posting_date_str.replace('Z', '+00:00'))
                else:
                    oldest_posting_date = oldest_posting_date_str
                earliest_next_post_date = oldest_posting_date + timedelta(days=30)
            
            return {
                'current_count': current_count,
                'max_count': 3,
                'can_post': can_post,
                'earliest_next_post_date': earliest_next_post_date,
                'recent_postings': [dict(p) for p in recent_postings],
                'all_active_postings': [dict(p) for p in all_active_postings]
            }

    def check_posting_cooldown(self, user_id: int, mode: str) -> bool:
        """Check if user can post (cooldown period)."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Check for recent postings in the same mode
            cooldown_date = datetime.now() - timedelta(days=Config.POSTING_COOLDOWN_DAYS)
            
            cursor.execute("""
                SELECT COUNT(*) as count FROM job_postings 
                WHERE user_id = ? AND mode = ? AND status = 'active' 
                AND created_at > ?
            """, (user_id, mode, cooldown_date))
            
            result = cursor.fetchone()
            return result['count'] == 0

    def get_user_active_postings_count(self, user_id: int) -> int:
        """Get count of active postings for user."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT COUNT(*) as count FROM job_postings 
                WHERE user_id = ? AND status = 'active'
            """, (user_id,))
            
            result = cursor.fetchone()
            return result['count']

    def check_user_posting_limit(self, user_id: int) -> tuple[bool, Optional[datetime]]:
        """
        Проверяет лимит публикаций пользователя за последние 30 дней.
        
        Returns:
            tuple[bool, Optional[datetime]]: 
                - can_post: можно ли публиковать
                - earliest_next_post_date: дата следующей возможной публикации (если лимит превышен)
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Получаем все активные объявления за последние 30 дней
            thirty_days_ago = datetime.now() - timedelta(days=30)
            
            cursor.execute("""
                SELECT created_at FROM job_postings 
                WHERE user_id = ? AND status = 'active' 
                AND created_at > ?
                ORDER BY created_at ASC
            """, (user_id, thirty_days_ago))
            
            recent_postings = cursor.fetchall()
            
            if len(recent_postings) < 3:
                # Меньше 3 объявлений - можно публиковать
                return True, None
            
            # Ровно 3 объявления - проверяем дату самого старого
            oldest_posting_date_str = recent_postings[0]['created_at']
            
            # Convert string to datetime if needed
            if isinstance(oldest_posting_date_str, str):
                oldest_posting_date = datetime.fromisoformat(oldest_posting_date_str.replace('Z', '+00:00'))
            else:
                oldest_posting_date = oldest_posting_date_str
                
            earliest_next_post = oldest_posting_date + timedelta(days=30)
            
            # Если 30 дней еще не прошли с самого старого объявления
            if earliest_next_post > datetime.now():
                return False, earliest_next_post
            
            # Если 30 дней прошли - можно публиковать
            return True, None

    def save_draft(self, user_id: int, **data) -> int:
        """Save draft."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Delete existing draft for user
            cursor.execute("DELETE FROM drafts WHERE user_id = ?", (user_id,))
            
            # Insert new draft
            fields = ['user_id'] + list(data.keys())
            placeholders = ['?'] * len(fields)
            values = [user_id] + list(data.values())
            
            cursor.execute(f"""
                INSERT INTO drafts ({', '.join(fields)}, created_at, updated_at)
                VALUES ({', '.join(placeholders)}, ?, ?)
            """, values + [datetime.now(), datetime.now()])
            
            conn.commit()
            return cursor.lastrowid

    def get_draft(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Get draft for user."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM drafts WHERE user_id = ?", (user_id,))
            result = cursor.fetchone()
            return dict(result) if result else None

    def delete_draft(self, user_id: int) -> bool:
        """Delete draft for user."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM drafts WHERE user_id = ?", (user_id,))
            conn.commit()
            return cursor.rowcount > 0

    def cleanup_expired_postings(self) -> tuple[int, list[dict]]:
        """
        Удаляет объявления старше 30 дней.
        
        Returns:
            tuple[int, list[dict]]: 
                - count: количество удаленных объявлений
                - deleted_postings: список удаленных объявлений с информацией
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Находим объявления старше 30 дней
            thirty_days_ago = datetime.now() - timedelta(days=30)
            
            # Получаем информацию об объявлениях для удаления
            cursor.execute("""
                SELECT id, user_id, mode, cities, name, message_id, chat_id, topic_id, created_at
                FROM job_postings 
                WHERE status = 'active' AND created_at < ?
            """, (thirty_days_ago,))
            
            expired_postings = cursor.fetchall()
            deleted_count = 0
            deleted_info = []
            
            for posting in expired_postings:
                # Сохраняем информацию для логирования
                posting_info = {
                    'id': posting['id'],
                    'user_id': posting['user_id'],
                    'mode': posting['mode'],
                    'cities': posting['cities'],
                    'name': posting['name'],
                    'message_id': posting['message_id'],
                    'chat_id': posting['chat_id'],
                    'topic_id': posting['topic_id'],
                    'created_at': posting['created_at']
                }
                deleted_info.append(posting_info)
                
                # Удаляем объявление (soft delete)
                cursor.execute("""
                    UPDATE job_postings 
                    SET status = 'expired', updated_at = ? 
                    WHERE id = ?
                """, (datetime.now(), posting['id']))
                
                deleted_count += 1
            
            conn.commit()
            return deleted_count, deleted_info


# Global database instance
db = Database()
