"""Alternative main entry point for Work in Portugal Bot."""

import asyncio
import logging
import sys
import os
import signal
import atexit
import fcntl
import subprocess

from aiogram import Bot, Dispatcher, Router, F
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import Config
from handlers.posting import router as posting_router

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("bot_alt.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Lock file for preventing multiple instances
LOCK_FILE = "bot_alt.lock"

def cleanup_stale_processes():
    """Clean up stale processes and lock files."""
    logger.info("Cleaning up stale processes...")
    
    try:
        # Kill any existing python processes running main_alternative.py
        result = subprocess.run(['pkill', '-f', 'python3 main_alternative.py'], 
                              capture_output=True, timeout=5)
        if result.returncode == 0:
            logger.info("Killed existing bot processes")
        else:
            logger.info("No existing bot processes found")
    except Exception as e:
        logger.warning(f"Error killing processes: {e}")
    
    # Remove stale lock file
    if os.path.exists(LOCK_FILE):
        try:
            os.remove(LOCK_FILE)
            logger.info("Removed stale lock file")
        except Exception as e:
            logger.warning(f"Error removing lock file: {e}")

class SingleInstance:
    """Ensure only one instance of the bot is running."""
    
    def __init__(self, lockfile):
        self.lockfile = lockfile
        self.fd = None
        
    def __enter__(self):
        """Acquire lock."""
        try:
            self.fd = open(self.lockfile, 'w')
            fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            logger.info(f"Lock acquired: {self.lockfile}")
            return self
        except IOError:
            logger.error(f"Another bot instance is already running")
            if self.fd:
                self.fd.close()
            sys.exit(1)
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Release lock."""
        if self.fd:
            try:
                fcntl.flock(self.fd, fcntl.LOCK_UN)
                self.fd.close()
                os.remove(self.lockfile)
                logger.info("Lock released")
            except Exception as e:
                logger.warning(f"Error releasing lock: {e}")

def signal_handler(signum, frame):
    """Handle termination signals."""
    logger.info(f"Received signal {signum}, shutting down...")
    sys.exit(0)

# Register signal handlers
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

# Create router
router = Router()

# Import handlers from main.py
from main import get_main_menu, get_back_button, cmd_start, show_main_menu, show_help, handle_mode_selection, handle_city_selection, show_my_postings

# Register handlers
router.message.register(cmd_start, Command("start"))
router.callback_query.register(show_main_menu, F.data == "go:main")
router.callback_query.register(show_help, F.data == "help")
router.callback_query.register(handle_mode_selection, F.data.startswith("mode:"))
router.callback_query.register(handle_city_selection, F.data.startswith("city:"))
router.callback_query.register(show_my_postings, F.data == "my_postings")

async def main():
    """Main function."""
    try:
        # Clean up any stale processes first
        cleanup_stale_processes()
        
        # Check if another instance is already running
        with SingleInstance(LOCK_FILE):
            # Validate configuration
            Config.validate()
            logger.info("Configuration validated successfully")

            # Initialize bot and dispatcher
            bot = Bot(token=Config.BOT_TOKEN)
            dp = Dispatcher(storage=MemoryStorage())

            # Register routers
            dp.include_router(router)
            dp.include_router(posting_router)

            logger.info("Work in Portugal Bot (Alternative) started successfully")

            # Start the dispatcher with different parameters
            await dp.start_polling(
                bot, 
                skip_updates=True,
                allowed_updates=["message", "callback_query"],
                polling_timeout=30,
                close_timeout=10
            )
            
            # Wait for termination signal
            try:
                await asyncio.Event().wait()
            except (KeyboardInterrupt, SystemExit):
                logger.info("Выключение...")
            finally:
                await dp.stop_polling()
                await bot.session.close()

    except ValueError as e:
        logger.error(f"Configuration error: {e}")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        sys.exit(1)
    finally:
        logger.info("Bot stopped")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)
