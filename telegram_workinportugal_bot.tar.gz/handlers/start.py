"""Start handler for Work in Portugal Bot."""

import logging
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext

from config import Config
from database import db
from keyboards.main import get_main_menu, get_help_keyboard

logger = logging.getLogger(__name__)
router = Router()


@router.message(Command("start"))
async def cmd_start(message: Message, state: FSMContext):
    """Handle /start command."""
    # Clear any active state
    await state.clear()
    
    # Create or update user
    user_id = db.create_user(
        telegram_id=message.from_user.id,
        username=message.from_user.username,
        first_name=message.from_user.first_name,
        last_name=message.from_user.last_name
    )
    
    logger.info(f"User {message.from_user.id} started bot")
    
    welcome_text = (
        "🤖 **Work in Portugal Bot**\n\n"
        "Добро пожаловать! Этот бот поможет вам опубликовать объявления "
        "о поиске или предложении работы в разделы Справочника.\n\n"
        "**Выберите действие:**"
    )
    
    await message.answer(welcome_text, reply_markup=get_main_menu())


@router.callback_query(F.data == "go:main")
async def show_main_menu(callback: CallbackQuery, state: FSMContext):
    """Show main menu."""
    # Clear any active state
    await state.clear()
    
    welcome_text = (
        "🤖 **Work in Portugal Bot**\n\n"
        "Добро пожаловать! Этот бот поможет вам опубликовать объявления "
        "о поиске или предложении работы в разделы Справочника.\n\n"
        "**Выберите действие:**"
    )
    
    await callback.message.edit_text(welcome_text, reply_markup=get_main_menu())
    await callback.answer()


@router.callback_query(F.data == "help")
async def show_help(callback: CallbackQuery):
    """Show help menu."""
    help_text = (
        "❓ **Помощь**\n\n"
        "Выберите раздел, который вас интересует:"
    )
    
    await callback.message.edit_text(help_text, reply_markup=get_help_keyboard())
    await callback.answer()


@router.callback_query(F.data == "help:rules")
async def show_rules(callback: CallbackQuery):
    """Show publication rules."""
    rules_text = (
        "📋 **Правила публикации**\n\n"
        "**Общие правила:**\n"
        "• Одно объявление не чаще раза в месяц\n"
        "• Максимум 3 активных объявления на пользователя\n"
        "• Объявления автоматически удаляются через 30 дней\n\n"
        "**Формат объявления:**\n"
        "• Хештеги городов (#lisboa, #porto, #online)\n"
        "• Описание работы (минимум 10 символов)\n"
        "• Социальные сети (или 'нет')\n"
        "• Telegram username\n"
        "• Телефон (+351xxxxxxxxx)\n"
        "• WhatsApp (если отличается)\n"
        "• Имя/название компании\n\n"
        "**Для работодателей:**\n"
        "• Несколько вакансий - одно объявление\n"
        "• Новые вакансии - редактирование существующего\n"
        "• Запрещено дублирование вакансий"
    )
    
    await callback.message.edit_text(rules_text, reply_markup=get_help_keyboard())
    await callback.answer()


@router.callback_query(F.data == "help:support")
async def show_support(callback: CallbackQuery):
    """Show support information."""
    support_text = (
        "📞 **Поддержка**\n\n"
        "Если у вас возникли вопросы или проблемы:\n\n"
        "**Telegram:** @support_username\n"
        "**Email:** support@example.com\n\n"
        "**Часы работы:**\n"
        "Пн-Пт: 9:00-18:00 (UTC+0)\n\n"
        "Мы постараемся ответить в течение 24 часов."
    )
    
    await callback.message.edit_text(support_text, reply_markup=get_help_keyboard())
    await callback.answer()
