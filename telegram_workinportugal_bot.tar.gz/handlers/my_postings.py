"""Handlers for 'My Postings' section."""

import json
from datetime import datetime
from typing import Optional

from aiogram import Router, F
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database import db
from config import Config
from utils import get_first_words

router = Router()


class DeletePostingStates(StatesGroup):
    """States for deleting posting."""
    confirm_delete = State()


def get_my_postings_keyboard(user_id: int) -> InlineKeyboardMarkup:
    """Create keyboard for my postings section."""
    postings = db.get_user_active_postings(user_id)
    
    keyboard = []
    
    for i, posting in enumerate(postings[:3], 1):
        # Get first words of description for button text
        description = posting.get('description', '')
        button_text = get_first_words(description, 5) or f"Объявление {i}"
        
        # Add posting button
        keyboard.append([InlineKeyboardButton(
            text=f"{i}. {button_text}",
            callback_data=f"posting_{posting['id']}"
        )])
    
    # Add back button
    keyboard.append([InlineKeyboardButton(
        text="⬅️ Назад",
        callback_data="go:main"
    )])
    
    return InlineKeyboardMarkup(inline_keyboard=keyboard)


def get_posting_menu_keyboard(posting_id: int) -> InlineKeyboardMarkup:
    """Create keyboard for posting menu."""
    keyboard = [
        [InlineKeyboardButton(
            text="🔍 Показать",
            callback_data=f"show_posting_{posting_id}"
        )],
        [InlineKeyboardButton(
            text="📊 Статистика",
            callback_data=f"stats_posting_{posting_id}"
        )],
        [InlineKeyboardButton(
            text="🗑️ Удалить",
            callback_data=f"delete_posting_{posting_id}"
        )],
        [InlineKeyboardButton(
            text="⬅️ Назад",
            callback_data="back_to_my_postings"
        )]
    ]
    
    return InlineKeyboardMarkup(inline_keyboard=keyboard)


def get_delete_confirmation_keyboard(posting_id: int) -> InlineKeyboardMarkup:
    """Create keyboard for delete confirmation."""
    keyboard = [
        [InlineKeyboardButton(
            text="✅ Да, удалить",
            callback_data=f"confirm_delete_{posting_id}"
        )],
        [InlineKeyboardButton(
            text="❌ Отмена",
            callback_data=f"cancel_delete_{posting_id}"
        )]
    ]
    
    return InlineKeyboardMarkup(inline_keyboard=keyboard)


@router.callback_query(F.data == "my_postings")
async def show_my_postings(callback: CallbackQuery):
    """Show user's postings."""
    user_id = callback.from_user.id
    
    # Get user from database
    user = db.get_user(user_id)
    if not user:
        await callback.message.edit_text(
            "❌ Пользователь не найден в базе данных.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="⬅️ Назад", callback_data="go:main")
            ]])
        )
        await callback.answer()
        return
    
    user_id_db = user['id']
    postings = db.get_user_active_postings(user_id_db)
    
    if not postings:
        await callback.message.edit_text(
            "📋 Мои объявления\n\n"
            "У вас пока нет активных объявлений.\n"
            "Создайте первое объявление в разделе 'Ищу работу' или 'Предлагаю работу'!",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="⬅️ Назад", callback_data="go:main")
            ]])
        )
        await callback.answer()
        return
    
    # Create keyboard with posting buttons
    keyboard = get_my_postings_keyboard(user_id_db)
    
    await callback.message.edit_text(
        f"📋 Мои объявления\n\n"
        f"У вас {len(postings)} активных объявлений:\n"
        f"Выберите объявление для управления:",
        reply_markup=keyboard
    )
    await callback.answer()


@router.callback_query(F.data.startswith("posting_"))
async def show_posting_menu(callback: CallbackQuery):
    """Show menu for specific posting."""
    posting_id = int(callback.data.split("_")[1])
    
    # Get posting details
    posting = db.get_posting_by_id(posting_id)
    if not posting:
        await callback.message.edit_text(
            "❌ Объявление не найдено.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="⬅️ Назад", callback_data="my_postings")
            ]])
        )
        await callback.answer()
        return
    
    # Check if user owns this posting
    user = db.get_user(callback.from_user.id)
    if not user or posting['user_id'] != user['id']:
        await callback.message.edit_text(
            "❌ У вас нет прав для управления этим объявлением.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="⬅️ Назад", callback_data="my_postings")
            ]])
        )
        await callback.answer()
        return
    
    # Get first words for title
    description = posting.get('description', '')
    title = get_first_words(description, 5) or "Объявление"
    
    # Create menu keyboard
    keyboard = get_posting_menu_keyboard(posting_id)
    
    await callback.message.edit_text(
        f"📋 Управление объявлением\n\n"
        f"**{title}**\n"
        f"Тип: {'Ищу работу' if posting['mode'] == 'seeking' else 'Предлагаю работу'}\n"
        f"Города: {posting['cities']}\n"
        f"Создано: {posting['created_at'].strftime('%d.%m.%Y %H:%M') if isinstance(posting['created_at'], datetime) else posting['created_at']}\n\n"
        f"Выберите действие:",
        reply_markup=keyboard
    )
    await callback.answer()


@router.callback_query(F.data.startswith("show_posting_"))
async def show_posting_link(callback: CallbackQuery):
    """Show posting link."""
    posting_id = int(callback.data.split("_")[2])
    
    posting = db.get_posting_by_id(posting_id)
    if not posting:
        await callback.answer("❌ Объявление не найдено", show_alert=True)
        return
    
    # Check ownership
    user = db.get_user(callback.from_user.id)
    if not user or posting['user_id'] != user['id']:
        await callback.answer("❌ Нет прав", show_alert=True)
        return
    
    if posting['message_id'] and posting['chat_id'] and posting['topic_id']:
        # Create link to the message in topic
        chat_username = "proflistpt"  # Remove @ for URL
        message_link = f"https://t.me/{chat_username}/{posting['topic_id']}/{posting['message_id']}"
        
        await callback.message.edit_text(
            f"🔍 Ссылка на ваше объявление:\n\n"
            f"{message_link}\n\n"
            f"Нажмите на ссылку, чтобы перейти к объявлению.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="⬅️ Назад", callback_data=f"posting_{posting_id}")
            ]])
        )
    else:
        await callback.message.edit_text(
            "❌ Ссылка на объявление недоступна.\n\nВозможно, объявление было удалено или перемещено.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="⬅️ Назад", callback_data=f"posting_{posting_id}")
            ]])
        )
    
    await callback.answer()


@router.callback_query(F.data.startswith("stats_posting_"))
async def show_posting_statistics(callback: CallbackQuery):
    """Show posting statistics."""
    posting_id = int(callback.data.split("_")[2])
    
    posting = db.get_posting_by_id(posting_id)
    if not posting:
        await callback.answer("❌ Объявление не найдено", show_alert=True)
        return
    
    # Check ownership
    user = db.get_user(callback.from_user.id)
    if not user or posting['user_id'] != user['id']:
        await callback.answer("❌ Нет прав", show_alert=True)
        return
    
    # Get user statistics
    stats = db.get_posting_statistics(user['id'])
    
    # Format statistics text
    stats_text = f"📊 Статистика публикаций\n\n"
    stats_text += f"**Текущие лимиты:**\n"
    stats_text += f"• Активных объявлений: {stats['current_count']}/{stats['max_count']}\n"
    stats_text += f"• Можно публиковать: {'✅ Да' if stats['can_post'] else '❌ Нет'}\n"
    
    if stats['earliest_next_post_date']:
        stats_text += f"• Следующая публикация: {stats['earliest_next_post_date'].strftime('%d.%m.%Y %H:%M')}\n"
    
    stats_text += f"\n**Ваши активные объявления:**\n"
    for i, p in enumerate(stats['all_active_postings'], 1):
        created_date = p['created_at']
        if isinstance(created_date, str):
            created_date = datetime.fromisoformat(created_date.replace('Z', '+00:00'))
        
        stats_text += f"{i}. {p['name']} ({p['mode']})\n"
        stats_text += f"   Создано: {created_date.strftime('%d.%m.%Y %H:%M')}\n"
        stats_text += f"   Города: {p['cities']}\n\n"
    
    await callback.message.edit_text(
        stats_text,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="⬅️ Назад", callback_data=f"posting_{posting_id}")
        ]])
    )
    await callback.answer()


@router.callback_query(F.data.startswith("delete_posting_"))
async def confirm_delete_posting(callback: CallbackQuery, state: FSMContext):
    """Show delete confirmation."""
    posting_id = int(callback.data.split("_")[2])
    
    posting = db.get_posting_by_id(posting_id)
    if not posting:
        await callback.answer("❌ Объявление не найдено", show_alert=True)
        return
    
    # Check ownership
    user = db.get_user(callback.from_user.id)
    if not user or posting['user_id'] != user['id']:
        await callback.answer("❌ Нет прав", show_alert=True)
        return
    
    # Store posting info in state
    await state.update_data(posting_id=posting_id)
    await state.set_state(DeletePostingStates.confirm_delete)
    
    # Get first words for title
    description = posting.get('description', '')
    title = get_first_words(description, 5) or "Объявление"
    
    # Create confirmation keyboard
    keyboard = get_delete_confirmation_keyboard(posting_id)
    
    await callback.message.edit_text(
        f"🗑️ Удаление объявления\n\n"
        f"Вы действительно хотите удалить объявление:\n"
        f"**{title}**\n\n"
        f"Это действие нельзя отменить!",
        reply_markup=keyboard
    )
    await callback.answer()


@router.callback_query(F.data.startswith("confirm_delete_"))
async def delete_posting(callback: CallbackQuery, state: FSMContext):
    """Delete the posting."""
    posting_id = int(callback.data.split("_")[2])
    
    posting = db.get_posting_by_id(posting_id)
    if not posting:
        await callback.answer("❌ Объявление не найдено", show_alert=True)
        return
    
    # Check ownership
    user = db.get_user(callback.from_user.id)
    if not user or posting['user_id'] != user['id']:
        await callback.answer("❌ Нет прав", show_alert=True)
        return
    
    try:
        # Delete from Telegram channel if possible
        if posting['message_id'] and posting['chat_id']:
            try:
                await callback.bot.delete_message(
                    chat_id=posting['chat_id'],
                    message_id=posting['message_id']
                )
            except Exception as e:
                # Log error but continue with database deletion
                print(f"Failed to delete Telegram message: {e}")
        
        # Delete from database
        success = db.delete_posting(posting_id)
        
        if success:
            await callback.message.edit_text(
                "✅ Объявление успешно удалено!\n\n"
                "Теперь вы можете создать новое объявление.",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                    InlineKeyboardButton(text="📋 Мои объявления", callback_data="my_postings"),
                    InlineKeyboardButton(text="⬅️ Главное меню", callback_data="go:main")
                ]])
            )
        else:
            await callback.message.edit_text(
                "❌ Ошибка при удалении объявления.",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                    InlineKeyboardButton(text="⬅️ Назад", callback_data=f"posting_{posting_id}")
                ]])
            )
        
        # Clear state
        await state.clear()
        
    except Exception as e:
        await callback.message.edit_text(
            f"❌ Ошибка при удалении: {str(e)}",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="⬅️ Назад", callback_data=f"posting_{posting_id}")
            ]])
        )
    
    await callback.answer()


@router.callback_query(F.data.startswith("cancel_delete_"))
async def cancel_delete_posting(callback: CallbackQuery, state: FSMContext):
    """Cancel posting deletion."""
    posting_id = int(callback.data.split("_")[2])
    
    # Get posting details to return to menu
    posting = db.get_posting_by_id(posting_id)
    if not posting:
        await callback.answer("❌ Объявление не найдено", show_alert=True)
        await state.clear()
        return
    
    # Check ownership
    user = db.get_user(callback.from_user.id)
    if not user or posting['user_id'] != user['id']:
        await callback.answer("❌ Нет прав", show_alert=True)
        await state.clear()
        return
    
    # Clear state
    await state.clear()
    
    # Get first words for title
    description = posting.get('description', '')
    title = get_first_words(description, 5) or "Объявление"
    
    # Create menu keyboard
    keyboard = get_posting_menu_keyboard(posting_id)
    
    await callback.message.edit_text(
        f"📋 Управление объявлением\n\n"
        f"**{title}**\n"
        f"Тип: {'Ищу работу' if posting['mode'] == 'seeking' else 'Предлагаю работу'}\n"
        f"Города: {posting['cities']}\n"
        f"Создано: {posting['created_at'].strftime('%d.%m.%Y %H:%M') if hasattr(posting['created_at'], 'strftime') else posting['created_at']}\n\n"
        f"Выберите действие:",
        reply_markup=keyboard
    )
    await callback.answer()


@router.callback_query(F.data == "back_to_my_postings")
async def back_to_my_postings(callback: CallbackQuery):
    """Go back to my postings list."""
    await show_my_postings(callback)
    await callback.answer()
