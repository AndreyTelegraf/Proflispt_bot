#!/usr/bin/env python3
"""Simple test script for bot connection."""

import asyncio
import logging
from aiogram import Bot, Dispatcher
from config import Config

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def test_bot():
    """Test bot connection."""
    try:
        # Initialize bot
        bot = Bot(token=Config.BOT_TOKEN)
        
        # Test connection
        me = await bot.get_me()
        logger.info(f"Bot connected successfully: {me}")
        
        # Test getting updates
        updates = await bot.get_updates()
        logger.info(f"Got {len(updates)} updates")
        
        # Close bot
        await bot.session.close()
        
        return True
        
    except Exception as e:
        logger.error(f"Error testing bot: {e}")
        return False

if __name__ == "__main__":
    print("🧪 Testing bot connection...")
    result = asyncio.run(test_bot())
    
    if result:
        print("✅ Bot test successful!")
    else:
        print("❌ Bot test failed!")
